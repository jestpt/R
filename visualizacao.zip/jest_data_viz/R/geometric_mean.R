geometric_mean <- function(x, na.rm = TRUE) {
  prod(x, na.rm = na.rm) ^ (1 / sum(!is.na(x)))
}